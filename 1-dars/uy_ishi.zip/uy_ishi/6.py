son=int(input("son: "))
for i in range(1,son+1):
   if son%i==0:
      print(i," ",end='')