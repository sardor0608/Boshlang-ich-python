son=int(input("son: "))
for i in range(1,11):
   print(f"{son}x{i}={son*i}")