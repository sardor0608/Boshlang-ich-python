n=500
kvadrati=0
son=1
while True:
   son+=1
   kvadrati=son**2
   if kvadrati>n:
      print(son,kvadrati)
      break   