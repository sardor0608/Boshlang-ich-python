son=int(input("son: "))
sana=0
while son!=0:
   son//=10
   sana+=1
print(f"Son {sana} xonali")