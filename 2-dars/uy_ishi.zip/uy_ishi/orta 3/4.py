son=(int(input("son kiriting: ")))
f=1
for i in range(son,0,-1):
   f*=i
print(f"{son} ning faktoriali: {f}")