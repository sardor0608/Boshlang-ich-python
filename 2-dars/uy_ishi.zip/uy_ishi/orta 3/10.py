for i in range(1, 11):
    for j in range(1, 11):
        print(f"{j} * {i} = {i * j:<4}", end="\t")
    print()
# Shu misol sal o'xshamadi
