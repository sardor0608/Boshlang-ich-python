a=int(input(" a sonni kiriting: "))
b=int(input(" b sonni kiriting: "))
saqla=a
for i in range(1,b):
   a*=saqla
print(a)