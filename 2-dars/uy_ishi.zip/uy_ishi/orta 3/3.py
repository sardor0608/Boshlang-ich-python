a=int(input(" a sonni kiriting: "))
b=int(input(" b sonni kiriting: "))
y=0
for i in range(a,b+1):
   y+=i
print(f"Yig'indi: {y}")