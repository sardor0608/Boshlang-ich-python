son=(int(input("son kiriting: ")))
sana=0
belgi=son
while son%2==0:
   son//=2
   sana+=1
print(f"{belgi} {sana} marta 2 ga bo'linadi")