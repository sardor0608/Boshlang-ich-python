son=(int(input("son kiriting: ")))
for i in range(1,son+1):
   print(i," ",end='')
for i in range(son-1,0,-1):
   print(i," ",end='')