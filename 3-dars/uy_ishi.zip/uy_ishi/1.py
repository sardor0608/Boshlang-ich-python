a=10
b=20
sonlar=[]
for i in range(a,b):
   if i%2==0:
      sonlar.append(i)
print(sonlar)