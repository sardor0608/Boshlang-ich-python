matn="salom aziz qalaysan"
lst1=matn.split()
lst1.sort()

print(lst1)