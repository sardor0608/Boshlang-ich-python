n=6
sonlar={}
for i in range(1,n):
   sonlar[i]=i**2
print(sonlar)