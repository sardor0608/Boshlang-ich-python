set1={2,3,4,5,6}
set2={4,5,6,7,8,9}
set1=set1.symmetric_difference(set2)
print(sum(set1))
