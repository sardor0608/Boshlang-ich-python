try:
    son=int(input("son kiriting: "))
except:
    print("Bu son emas iltimos, son kiriting!")
