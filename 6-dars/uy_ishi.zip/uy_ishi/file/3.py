file=open("capitals.txt", "r")
   # lst=['Rim', 'Pekin', 'Parij', 'Ottava', 'Anqara']
   # for i in lst:
   #    file.write(f"{i} ")
file1=open("countries.txt", "r")
   # lst2=['Italya','Xitoy', 'Fransiya', 'Kanada' ,'Turkiya']
   # for i in lst2:
   #    file1.write(f"{i} ")
lst3=file.readline()
print(lst3)

