file1=open("fayl.txt","r")
file2=open("ildiz.txt","w")
